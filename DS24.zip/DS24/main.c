/*************************************************************************
 // Tapez votre identifiant et groupe ici :
* ************************************************************************/

#include <stdio.h>
#include <stdlib.h>

//******************* STRUCUTRES DE DONNEES  ****************************

        //Definissez les structures dans cet espace



//************ PROTOTYPE DES FONCTIONS  *********************************
        //Definissez les fonctions dans cet espace
        //il s'agit de d�clarations sans code

int  Menu();


//******************* PROGRAMME PRINCIPAL  ****************************
int main()

{

        // declarer vos variables principales ici
        int choix = -1 ;



        while(choix != 0 )
        {
            choix = Menu();
            // completez par votre code du programme principal


        }

        return 0;
}


//************ CODE DES FONCTIONS  *********************************

int  Menu()
{
    int  choix;
    printf("******************\n");
    printf("MENU:\n");
    printf("  1 :  \n");
    printf("  2 :  \n");
    printf("  3 :  \n");
    printf("  4 :  \n");
    printf("  5 : \n");
    printf("  6 : \n");
    printf("  0 : Quitter\n\n");
    printf(" votre choix : ");
    scanf("%d",&choix);
    printf("***************** \n\n");
    getchar(); //pour nettoyer le fichier de saisie et le pr�parer pour une autre saisie � blanc

    return choix;
}
